# Asha Baker Instructional Design Portfolio

Chromebook-friendly flat-file version for GitHub Pages.

## Upload instructions
1. Unzip this folder.
2. Open the GitHub repository.
3. Click **Add file > Upload files**.
4. Upload the files from inside this folder.
5. Commit changes.
6. Wait 1-3 minutes and refresh the GitHub Pages site.

This version keeps all files in the repository root and updates the HTML to reference `styles.css`, `script.js`, PDFs, and the resume from the root level.

## Portfolio note
All samples are original, sanitized, or representative examples created for demonstration purposes. No confidential, proprietary, government-controlled, client-sensitive, or internal employer materials are included.
